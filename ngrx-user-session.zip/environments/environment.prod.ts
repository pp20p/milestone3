export const environment = {
  production: true,
  apiUrl: 'https://eshop-backend-bluebits.herokuapp.com/api/v1/'
};
