import 'jest-preset-angular/setup-jest';
