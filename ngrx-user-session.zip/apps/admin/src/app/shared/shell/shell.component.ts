import { Component } from '@angular/core';

@Component({
  selector: 'admin-shell',
  templateUrl: './shell.component.html'
})
export class ShellComponent {
  constructor() {}
}
