import { Component } from '@angular/core';

@Component({
  selector: 'ngshop-home-page',
  templateUrl: './home-page.component.html'
})
export class HomePageComponent {}
