import { Component } from '@angular/core';

@Component({
  selector: 'ngshop-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent {}
