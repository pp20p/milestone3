export class OrderItem {
  product?: string;
  quantity?: number;
}
